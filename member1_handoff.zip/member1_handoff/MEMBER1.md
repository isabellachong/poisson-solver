# Member 1：串行、验证与 benchmarking 交接

## 当前交付状态（2026-11-11）

你的串行实现、公共测试、Vanda 串行实测、单 GPU 数值验证、数据分析和报告整理已完成。
本轮结果来自实际 Vanda 作业，不是之前的 Mac 测试。

- **英文报告**：`docs/member1_report.md`；可阅读的 PDF 为 `output/pdf/member1_report.pdf`。
- **正式图表与数据表**：`docs/member1_results/serial_runtime.png`、`refinement.png` 和 `serial_summary.csv`。
- **串行作业 1542371**：Xeon Platinum 8452Y，申请 1 CPU 核，GCC 13.1.0；2D/3D 各 4 种规模，每种 5 次、每次 2,000 次迭代，共 40 条计时。
- **正确性**：Vanda 上 64 个固定步数算例、6 次收敛求解及原有测试通过；下载后独立重查了全部 64 组串行解向量。
- **GPU 验证作业 1537115**：一块 NVIDIA A40、4 MPI ranks、host staging；2D/3D、overlap=0/1 的数值比较通过。不是 GPU 性能 scaling 实验。
- **组内交接包**：`output/member1_handoff.zip`，含报告、图表、原始性能 CSV、复现脚本和代码，不含日志、终端输出、构建文件或账号配置。

你现在无需再提交串行作业。还需全组协调的是：MPI 至少 256 CPU 核的 strong/weak scaling、MPI+CUDA 的性能实验及最终合并报告。如果你负责全组绘图，拿到组员的并行 CSV 后还需要做这部分汇总；已有脚本支持这些工作。

### 从下载结果重新生成图表

```sh
python3 scripts/analyze_member1.py
python3 scripts/plot_member1.py
```

第一条仅需 Python 标准库，第二条需要 matplotlib。需要重建 PDF 时，另安装 reportlab，并执行 `python3 scripts/render_member1_report.py`。报告 Markdown 是可编辑正文。

保留本地 `results/vanda-*/` 和下载的 tar.gz 作为实验凭据；课程说明要求不要提交原始日志/终端输出，交接包已排除它们。

## 实现范围与运行说明

范围已按你的确认更新：求解 **2D 和 3D Poisson 问题**，并行采用 **2D 分解**，不做 1D 分解；正式性能实验使用 **Vanda**。本次沿用并验证已有 C++ 串行实现，未修改组员的 MPI/CUDA 代码。

注意区分 problem dimension 和 process-grid dimension：三维问题也可以用 `--dim 3 --px 2 --py 2 --pz 1`，即只沿两个坐标方向分解。原 README 中的 `2x2x2` 示例属于沿三个方向分解，并非本次约定。

## 你的交付内容

| 内容 | 文件 | 状态 |
| --- | --- | --- |
| 串行入口、Jacobi 双缓冲更新 | `executables/poisson_serial.cpp`, `src/cpu_backend.cpp`, `src/solver.cpp` | 沿用已有实现，本机编译并验证 |
| 共同测试问题与边界条件 | `src/problem.cpp` | 四种问题，2D/3D 均已校验 |
| 独立数值验证、误差表、二阶精度图 | `scripts/validate_serial.py` | 新增，已运行 |
| 不依赖 MPI/CUDA/CMake 的构建 | `scripts/build_serial.sh` | 新增 |
| 一次完成串行构建、验证、计时、绘图 | `scripts/run_member1.sh` | 新增 |
| 重复实验、CSV、命令及环境记录 | `scripts/benchmark.py` | 已增强并实测 |
| runtime、speedup、efficiency、统计表 | `scripts/plot_scaling.py` | 已增强并验证 |
| benchmark/绘图的数据一致性测试 | `tests/test_analysis_scripts.py` | 新增 |
| 可并入小组报告的英文正文 | `docs/member1_report.md` | 已写入实际 Vanda 验证、串行性能和分析 |

## 本地快速复现

需要 C++17 编译器、Python 3 和 matplotlib。已有 matplotlib 就不用安装。

```sh
python3 -m pip install -r requirements-analysis.txt
sh scripts/run_member1.sh build-member1 results/local-member1
```

运行脚本始终从项目根目录执行。`CXX` 可指定编译器，`PYTHON` 可指定 Python。若 matplotlib 缓存目录不可写，可设置 `MPLCONFIGDIR=/tmp/poisson-matplotlib`。脚本拒绝覆盖已有结果，重跑时换一个输出目录。

也可使用已有 CMake：

```sh
cmake -S . -B build-serial -DPOISSON_ENABLE_MPI=OFF -DPOISSON_ENABLE_CUDA=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-serial -j 4
ctest --test-dir build-serial --output-on-failure
python3 scripts/validate_serial.py --exe build-serial/executables/poisson_serial --output-dir results/local-check2 --plot
```

验证输出包含 `checks.csv`、`refinement.csv`、`refinement.png`、每次运行的解向量 CSV 和 `run.json`。

本轮已经生成：

- `results/local-validation/`：64 个固定步数算例、6 个收敛求解及误差图。
- `results/local-benchmark/`：2D/3D 各 9 次真实本地 smoke measurements 和绘图。
- `results/local-member1-final/`：一键脚本完整实测输出，含验证结果、2D/3D 各 20 次计时、环境记录及统计图。
- 本机环境为 macOS ARM64、AppleClang 14.0.3、Python 3.12、matplotlib 3.10.0。本轮没有 CMake/MPI/CUDA，使用 C++ 命令直接构建并运行测试。

这些本机目录被 `.gitignore` 排除，避免误当正式实验数据。需要交给组员时可复制对应文件；**不得将其标成 Vanda 性能数据**。

## 公共数值约定

- 方程为 `-laplacian(u)=f`，单位正方形/立方体，Dirichlet 边界。
- `nx/ny/nz` 是内部点数，`h_a=1/(N_a+1)`；边界不计入未知数。
- double precision，内部初值为零；两个解数组均初始化固定边界，每一步读旧数组、写新数组后交换。
- `sine`：二阶空间精度；`mixed`：多个频率，避免只测单一模式；`polynomial`：非零边界且二阶差分精确；`zero`：初始即收敛。
- 收敛条件为 `max|f-A_h u| <= atol + rtol*max|f|`，不是相邻迭代差。
- 性能实验统一 `--check-every 0`、相同问题、相同迭代数、相同 warmup。固定迭代实验即使 `converged=0` 也可成功结束，不能据此声称解已收敛。

## 在 Vanda 上运行

在**已申请的计算节点作业内**、加载课程要求的编译器和 Python 环境后执行：

```sh
EXPERIMENT_LABEL=vanda-same-cpu-gpu-model CXX=g++ sh scripts/run_member1.sh build-member1-vanda results/vanda-member1
```

标签应描述固定的机器/软件实验环境；同一 scaling study 的不同资源数量使用同一个标签。不同硬件或编译设置用不同标签，防止绘图误合并。`CXX=g++` 只是编译器选择示例，需以课程实际模块为准。

脚本进行 5 次重复，默认串行规模为 2D `128,256,512,1024`，3D `16,32,64,128`，每次 500 次迭代、3 次 warmup。先跑小规模确认耗时和内存，再按并行实验的全局规模补串行基线。很快的实验应增加迭代数，使计时明显大于噪声；所有被比较的版本必须一起调整。

正式记录应另附：Vanda 作业 ID、节点/CPU 型号、GPU 型号和数量、每 GPU 的 rank 数、CPU 绑定、编译器及优化参数、MPI/CUDA 版本、模块列表和 MPS 状态。`*.metadata.json` 记录启动主机与可执行文件 SHA256；`*.runs.jsonl` 记录实际命令和 stdout/stderr（包括 GPU mapping）。启动主机元数据不能替代计算节点硬件记录。

已有并行程序时，可由你运行共同验证脚本（3D 测试明确用 2D 分解）：

```sh
python3 tests/validate_mpi.py --serial build-gpu/executables/poisson_serial --parallel build-gpu/executables/poisson_mpi --backend cuda --grid2d 2x2 --grid3d 2x2x1
```

此命令需有足够的 rank/GPU 资源、正确的 MPI launcher 和 CUDA-aware MPI。CPU 版本改为 `--backend cpu` 与对应可执行文件路径。若课程环境不支持 CUDA-aware MPI，可先加 `--communication host` 验证 host staging，不能声称验证了另一种通信方式。

正式 benchmark 示例（均需在足够的已分配资源中运行）：

```sh
# 四块及以上 GPU 才能测相应的真实 GPU scaling；不要把共享一块 GPU 当作多 GPU scaling。
python3 scripts/benchmark.py --exe build-gpu/executables/poisson_mpi --mode mpi-cuda --kind strong --dim 2 --process-grids 1x1 2x2 --nx 1024 --ny 1024 --iterations 500 --repeats 5 --label vanda-same-cpu-gpu-model --output results/vanda-strong2d.csv

# 三维问题仍只沿两个方向分解。
python3 scripts/benchmark.py --exe build-gpu/executables/poisson_mpi --mode mpi-cuda --kind strong --dim 3 --process-grids 1x1x1 2x2x1 --nx 128 --ny 128 --nz 128 --iterations 500 --repeats 5 --label vanda-same-cpu-gpu-model --output results/vanda-strong3d.csv

# 同一环境、网格、问题、迭代数及 warmup 的串行基线。
python3 scripts/plot_scaling.py --input results/vanda-strong2d.csv results/vanda-strong3d.csv --serial-reference results/vanda-member1/serial2d.csv results/vanda-member1/serial3d.csv --output-dir results/vanda-figures
```

对于 weak scaling，改 `--kind weak`，此时 `nx/ny/nz` 表示每个 rank 的局部内部点数。GPU weak scaling 还必须保持 ranks/GPU 不变。只有一块 GPU 时用 `--kind sharing` 做共享 GPU 实验。具体最大规模和 process grids 由实际资源决定。

图表中 `relative_speedup` 以同一并行系列的最小资源点为基线；`speedup_vs_serial` 以匹配的串行 CPU 实验为基线，二者含义不同。GPU 加速比可报告相对串行 CPU 的加速，但不能直接解释成同构 CPU 核的并行效率。

## 与组员衔接

正式串行基线是 **mixed 问题、2,000 iterations、3 warmup、check_every=0**。
之前示例中的 500 次迭代仅用于演示；与本轮基线计算加速比时，必须将并行版本也设为 2,000 次并匹配网格。
新的 GPU host-staging 验证已完成；CUDA-aware、多 GPU、GPU 收敛停止和实际通信计算重叠尚需按最终采用的模式测试。
MPI/GPU 的性能 CSV 尚未包含在此次下载包中，因此不能从本轮数据生成真实的并行加速比或效率结论。
