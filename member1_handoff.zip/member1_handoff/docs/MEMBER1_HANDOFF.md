# Member 1 交接说明

本包用于组内合并，**不是全组最终提交包**。先读 `output/pdf/member1_report.pdf`；
需要修改或合并正文时使用 `docs/member1_report.md`。

## 已完成

- 现有 2D/3D C++ 串行 Jacobi 实现的验证和公共测试问题。
- Vanda 串行性能：job 1542371，40 次计时，CPU 为 Xeon Platinum 8452Y。
- Vanda 数值验证：64 个固定步数算例、6 次网格加密收敛求解。
- Vanda MPI+CUDA 正确性：job 1537115，一块 A40 共享给 4 MPI ranks，
  2D/3D 的 host staging、overlap=0/1 均通过独立数值比较。
- 英文报告、真实实验图、全精度表，以及可复用 benchmark/绘图脚本。

包内包含现有共享及并行代码以便复现构建；这些代码并非全部由 Member 1 编写。
本次后处理没有修改组员的 MPI/CUDA 实现。

## 关键实验约定

正式串行基线使用 `mixed`、`iterations=2000`、`warmup=3`、`check_every=0`，
每个规模 5 次重复。2D 内部网格为 128²、256²、512²、1024²；3D 为 16³、32³、64³、128³。
网格不含边界点。计时只统计 solve 阶段，报告中已说明排除项。
大多数计时算例未收敛，因为这里比较固定工作量；精度结论来自另行求解到容差的验证。

`serial_summary.csv` 的 `median_seconds` 为五次计时中位数，`min_seconds/max_seconds`
为范围，`million_updates_per_second` 为 M×2000/median/10^6，`converged_runs`
为达到默认残差阈值的重复次数。不要把该字段当作固定步数实验是否执行成功的标志。

## 文件位置

- 正文/PDF：`docs/member1_report.md`、`output/pdf/member1_report.pdf`
- 图表/统计表：`docs/member1_results/`
- 原始性能 CSV 和验证表：`results/vanda-member1-serial-1542371.stdct-mgmt-02/`
- 构建与验证：`scripts/build_serial.sh`、`scripts/validate_serial.py`、`tests/validate_mpi.py`
- 通用实验与绘图：`scripts/benchmark.py`、`scripts/plot_scaling.py`
- 本轮数据审计和图表：`scripts/analyze_member1.py`、`scripts/plot_member1.py`
- Vanda 提交脚本：`jobs/vanda_member1_serial.pbs`、`jobs/vanda_gpu_validate.pbs`

`#PBS -P` 中的 project ID 属于原执行者，组员复跑时应替换为自己有权限使用的项目。
并行实验的申请核数、GPU 数量和绑定设置也要与实际分配一致。

## 本地复现

```sh
sh scripts/build_serial.sh build-member1
python3 scripts/validate_serial.py --exe build-member1/executables/poisson_serial --output-dir results/new-validation
python3 -m pip install -r requirements-analysis.txt
python3 scripts/plot_member1.py
```

最后一条从已有的审计结果 `analysis.json` 重建正式图表，不会重新计时。
重建 PDF 还需 `reportlab`，命令为 `python3 scripts/render_member1_report.py`。
完整 `analyze_member1.py` 审计需要原始运行日志、JSONL 和解向量；这些完整凭据
保存在执行者本地的 `member1-vanda-results.tar.gz`，按课程要求未放入本交接包。

## 全组仍需补齐

- MPI CPU 至少 256 核的 strong/weak scaling、加速比、效率及通信分析。
- MPI+CUDA 的性能实验；正确性通过不能证明加速或通信计算重叠。
- 若最终使用 CUDA-aware、多 GPU 等未验证模式，补充相应正确性测试。
- 合并报告，补齐组员姓名/学号、分工及最终 AI 使用说明。

如果 Member 1 还负责最终并行图表，需要组员提供匹配问题、网格、迭代数、
warmup 和计时口径的 CSV。不能用本包的串行数据推测未测量的并行性能。
