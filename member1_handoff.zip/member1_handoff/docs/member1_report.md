# Serial baseline, common validation, and benchmarking methodology

This section covers Member 1's contribution. The study solves both two- and
three-dimensional problems. Distributed experiments are intended to partition
two spatial directions; for a 3D problem, a process grid such as 2x2x1 is used.
The results below use actual Vanda executions: serial validation and performance
job 1542371 on 11 November 2026, and MPI+CUDA numerical validation job 1537115
on 10 November 2026. This section establishes a serial baseline and correctness
evidence. Parallel performance scaling is a separate group deliverable.

## Problem and serial algorithm

We solve the Poisson equation

\[
-\nabla^2u(\mathbf{x})=f(\mathbf{x}),\qquad
\mathbf{x}\in(0,1)^d,\quad d\in\{2,3\},
\]

with prescribed Dirichlet boundary values. For N_a interior points along axis a,
the grid spacing is h_a=1/(N_a+1). Central differences give a five-point stencil
in 2D and a seven-point stencil in 3D. Jacobi updates are

\[
u_{\mathbf{i}}^{(k+1)}=
\frac{f_{\mathbf{i}}+\sum_{a=1}^{d}
 h_a^{-2}(u_{\mathbf{i}-\mathbf{e}_a}^{(k)}+
 u_{\mathbf{i}+\mathbf{e}_a}^{(k)})}
 {2\sum_{a=1}^{d}h_a^{-2}}.
\]

The serial C++17 implementation uses double precision and two solution arrays.
All updates read the old array and write the new array; the arrays are swapped
after each iteration. Both arrays contain the prescribed physical boundaries,
which are never updated. Interior values start at zero. The matrix is implicit,
so storage and work per iteration are O(M), where M is the number of interior
unknowns. RHS values are computed once during initialization. The serial
executable does not initialize MPI or require a GPU.

The shared problem definitions, indexing and numerical settings allow direct
comparison with parallel implementations. However, agreement between versions
that share code is insufficient by itself: we also use independent Python
references and analytical discrete eigenmodes.

## Common test problems

Let q(t)=t(1-t). We prescribe boundary values from the following exact solutions
and set f=-laplacian(u_exact):

| Problem | 2D exact solution | 3D extension | Purpose |
| --- | --- | --- | --- |
| sine | sin(pi*x)sin(pi*y) | Multiply by sin(pi*z) | Spatial accuracy and discrete eigenmode checks |
| mixed | sin(pi*x)sin(pi*y)+0.25sin(2pi*x)sin(3pi*y) | Multiply the entire expression by sin(pi*z) | Multiple spatial frequencies |
| polynomial | x+2y+q(x)q(y) | x+2y+3z+q(x)q(y)q(z) | Nonzero boundary values and a discretely exact solution |
| zero | 0 | 0 | Initial convergence and zero preservation |

For the sine solution f=d*pi^2*u_exact. For the mixed solution the first mode
has coefficient d*pi^2 and the second mode has coefficient (d+11)*pi^2.
For the polynomial, f=2(q(x)+q(y)) in 2D and
f=2(q(x)q(y)+q(x)q(z)+q(y)q(z)) in 3D. Because it is quadratic in each coordinate,
the polynomial has exact central second differences up to roundoff, but
finite-step Jacobi still has iteration error.

Convergence is tested using the true discrete residual:

\[
\|f-A_hu\|_\infty \leq \mathrm{atol}
 +\mathrm{rtol}\|f\|_\infty.
\]

We report maximum solution error and interior RMS error separately from the
residual. These measure different quantities: the residual concerns the discrete
system, whereas the solution error also includes spatial discretization error.

## Independent validation and observed accuracy

The executable validation checks complete owned solution vectors, not only a
checksum. The polynomial reference independently evaluates the update in Python.
For sine modes with integer frequencies m_a, a second reference uses

\[
\lambda_h=4\sum_a h_a^{-2}\sin^2(m_a\pi h_a/2),\quad
D=2\sum_a h_a^{-2},\quad \rho=1-\lambda_h/D.
\]

Starting from zero, the discrete Jacobi solution after K steps for an exact-mode
amplitude c is c*(lambda_cont/lambda_h)*(1-rho^K) times the sampled sine mode,
where lambda_cont=pi^2*sum_a(m_a^2). This reference does not reproduce the stencil
loop. Multiple modes are added by linearity.

On 11 November 2026, execution on Vanda with GCC 13.1.0 and
`-std=c++17 -O3 -DNDEBUG` passed:

- Seven existing C++ numerical test groups (including simulated in-process face
  exchange; these are not actual MPI communication tests).
- 64 independent fixed-step cases: both dimensions, all four problems,
  unequal-spacing and thin grids, and K=0,1,2,9. Warm-up is followed by a reset.
- Six converged sine solves for grid refinement.
- Four existing executable checks covering independent polynomial references,
  initially converged zero data, and failure to reach tolerance by the iteration limit.

The refinement solves use rtol=1e-11, atol=1e-12, and residual checks every ten
iterations. With equal N in each active coordinate, the measured maximum errors
are:

| Dimension | N | h | Maximum error | Observed order | Iterations |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2D | 7 | 1/8 | 1.295074671e-2 | — | 320 |
| 2D | 15 | 1/16 | 3.218964431e-3 | 2.00837 | 1310 |
| 2D | 31 | 1/32 | 8.035776695e-4 | 2.00209 | 5250 |
| 3D | 7 | 1/8 | 1.295074671e-2 | — | 320 |
| 3D | 15 | 1/16 | 3.218964431e-3 | 2.00837 | 1310 |
| 3D | 31 | 1/32 | 8.035776695e-4 | 2.00209 | 5250 |

The observed order is log2(E_h/E_(h/2)). The results are consistent with
second-order accuracy. Equal maximum errors across dimensions are expected for
this equal-spacing product-sine case: the dimension factors cancel in the ratio
of continuous and discrete eigenvalues. RMS errors differ across dimensions.
The generated `refinement.csv` contains full-precision errors and residuals.

![Vanda grid refinement](member1_results/refinement.png)

Figure 1. Measured maximum errors for the converged sine problem. The dashed
reference decreases proportionally to the square of grid spacing. Each panel
uses the Vanda results, not the earlier local smoke measurements.

Actual MPI+CUDA validation also passed on Vanda node GN-A40-094 using one NVIDIA
A40 GPU shared by four MPI ranks. The executable was built with NVHPC 26.1.0,
CUDA compiler 12.9.86, CMake 3.29.3 and the nvhpc-hpcx-cuda12/26.1 module. The
recorded driver was 575.57.08. The job requested 36 CPU cores, four MPI processes
and one GPU; the validator ran MPI with `--bind-to none`.

The eight executable checks comprise two serial polynomial references, four GPU
comparisons (2D/3D, each with overlap disabled/enabled), and two serial stopping
checks. GPU cases use nine iterations on a 9x7 grid or 9x7x5 grid, two warm-up
iterations followed by reset, and process grids 2x2 and 2x2x1. These include
uneven subdomains. Each owned value is compared with an independent Python
reference using relative tolerance 1e-11 and absolute tolerance 1e-12. Residuals
use relative tolerance 1e-10 and absolute tolerance 1e-9.

These GPU results establish numerical agreement for host-staged communication
on the tested small cases. CUDA-aware communication, multiple GPUs, GPU
convergence stopping, memory sanitization and actual overlap in a profiler were
not verified by this run. The imported GPU log records all eight checks passing;
individual GPU solution files were temporary and are not included in the archive.
The 64 saved serial solution vectors were independently rechecked after download.

## Benchmarking protocol

The measured serial size sweep uses 2,000 iterations of the mixed problem with
convergence checks disabled (`check_every=0`). This keeps work comparable.
Three warm-up iterations are untimed and the solution is reset afterwards.
Every configuration is repeated five times in separate executable invocations.
We summarize median runtime with minimum/maximum variation. For future parallel
experiments the collector alternates overlap order across repeats.

The measured `solve_seconds` includes iteration, halo communication and any
packing/unpacking. For MPI runs it is the maximum elapsed solve time across ranks.
It excludes setup, warm-up, the initial barrier, final diagnostics and solution
output. GPU computation must be complete before the timing interval ends. The
recorded times are solver-phase measurements, not full batch-job wall times.

For strong scaling, the global grid, problem and iteration count remain fixed.
Relative speedup and efficiency are

\[
S(p;p_0)=T(p_0)/T(p),\qquad
E(p;p_0)=S(p;p_0)/(p/p_0).
\]

The baseline resource count p_0 is reported explicitly. A separate serial CPU
speedup is T_serial/T_parallel and is computed only from matching grids,
problems, iteration counts, warm-up settings and experiment labels. For weak
scaling, work per resource remains fixed and efficiency is T(p_0)/T(p).

CPU parallel studies should count allocated CPU ranks/cores with one core bound per rank. GPU
hardware scaling uses the actual physical GPUs reported by the solver. Holding
one GPU fixed while increasing ranks is a GPU-sharing study; its relative
speedup is not a multi-GPU hardware efficiency. GPU weak scaling also holds
ranks/GPU fixed. The CPU-to-GPU speedup is a heterogeneous comparison and should
not be interpreted as same-core-count CPU efficiency.

The collector saves raw CSVs, executable SHA256, invocation arguments, launcher
host information, and per-run commands/stdout/stderr. A companion experimental
record must identify Vanda job ID, compute hardware, binding, allocated resources,
compiler flags, MPI/CUDA versions, loaded modules and MPS status. Plotting refuses
nonfinite timings, mismatched strong-scaling grid shapes and unmatched serial
references. Environment labels separate incompatible experimental series.

## Vanda serial performance results

The serial job ran on compute node GN-A40-075, with an Intel Xeon Platinum 8452Y
CPU, GCC 13.1.0 and Python 3.9.19. The PBS script requested one CPU core and
set OMP_NUM_THREADS=1. The solver has no OpenMP threads and used no GPU, even
though the node name includes A40. The host has 72 CPU cores; this does not mean
the serial experiment used 72 cores. Exact CPU affinity and competing node
workloads were not recorded. Results are five process invocations within one
allocation rather than five independent allocations.

The matrix dimension is M by M, where M is the number of interior unknowns.
After eliminating prescribed boundary values, the implicit nonzero counts are:

- 2D: M=Nx*Ny and nnz=5M-2(Nx+Ny).
- 3D: M=Nx*Ny*Nz and nnz=7M-2(Nx*Ny+Nx*Nz+Ny*Nz).

Both matrix dimension and nonzero count change across the size sweep. They are
coupled for each fixed stencil, so this is not a study of independently varying
sparsity. No sparse matrix is explicitly stored.

| Problem | Grid | M | nnz | Median (s) | Min-max (s) |
| --- | --- | ---: | ---: | ---: | --- |
| 2D | 128 x 128 | 16,384 | 81,408 | 0.024016 | 0.023506-0.029999 |
| 2D | 256 x 256 | 65,536 | 326,656 | 0.100810 | 0.095024-0.102816 |
| 2D | 512 x 512 | 262,144 | 1,308,672 | 0.542819 | 0.513944-0.558868 |
| 2D | 1024 x 1024 | 1,048,576 | 5,238,784 | 3.227416 | 2.984299-3.304203 |
| 3D | 16 x 16 x 16 | 4,096 | 27,136 | 0.010540 | 0.010490-0.010627 |
| 3D | 32 x 32 x 32 | 32,768 | 223,232 | 0.073604 | 0.072508-0.073774 |
| 3D | 64 x 64 x 64 | 262,144 | 1,810,432 | 0.659936 | 0.635688-0.754357 |
| 3D | 128 x 128 x 128 | 2,097,152 | 14,581,760 | 7.704453 | 7.697444-7.770589 |

![Vanda serial runtimes](member1_results/serial_runtime.png)

Figure 2. Median solve time for 2,000 fixed iterations, with min-max error bars
over five repetitions. Both axes are logarithmic. Dotted lines show linear-work
references anchored at the smallest measured case in each dimension; they are
not fitted performance predictions.

For a fixed iteration count K, Jacobi performs O(KM) work. Fitting log(T) against
log(M) across the four medians gives slopes 1.182 for 2D and 1.057 for 3D.
These describe the measured range and do not change the algorithmic complexity.
The 2D throughput declines from about 1,364 to 650 million cell updates/s across
the measured range. The 3D throughput is about 777 to 890 million updates/s on
the two smallest grids and 544 million updates/s on the largest grid. Changes
in cache use, memory traffic and effective memory bandwidth are plausible
contributors to the larger-grid slowdown, but were not isolated by profiling.

At equal M=262,144, the 3D case takes 0.660 s versus 0.543 s for 2D, about 1.22
times as long. The seven-point 3D stencil uses more neighbours per update than
the five-point 2D stencil and has different access patterns. Their implicit nnz
counts differ by about 1.38 times. Runtime should not be attributed solely to
nnz: dimensionality and memory access also change.

These fixed-work timings are not time-to-convergence measurements. Only the
smallest 3D grid reached the configured residual threshold within 2,000 steps;
the other seven configurations did not. This is expected for plain Jacobi at
larger sizes and does not invalidate a fixed-iteration comparison. Converged
accuracy is established separately by the refinement experiments. As refinement
also increases the required iteration count, total solve-to-tolerance complexity
can grow faster than the fixed-K size sweep shown here.

## Evidence and remaining group experiments

The source CSVs contain 40 measurements, each matched against its captured
solver stdout. Every size has repeat indices 0 through 4, and both dimensions
use the same executable SHA256. The analysis additionally checks the M/nnz
formulas, finite times and residuals, the saved serial solution vectors, and
the six refinement results. `scripts/analyze_member1.py` reproduces this audit;
`scripts/plot_member1.py` recreates the figures from its derived data.

Source records are the serial2d.csv, serial3d.csv and validation/refinement.csv
files from Vanda job 1542371.stdct-mgmt-02, plus the successful numerical
validation log from job 1537115.stdct-mgmt-02. Submission scripts are
`jobs/vanda_member1_serial.pbs` and `jobs/vanda_gpu_validate.pbs`. The derived
full-precision table is `docs/member1_results/serial_summary.csv`. Raw logs are
retained for provenance and are excluded from the report and submission package.

This section does not supply MPI strong/weak scaling to 256 CPU cores or MPI+CUDA
performance scaling. The group still needs those measured results, parallel
speedup/efficiency plots and communication analysis. The serial benchmark
collector and plotting tools are ready to support those comparisons. Any paired
parallel runs must use the same problem, grid and 2,000-iteration timing scope,
and document their compiler and hardware settings. No GPU speedup or overlap
benefit can be inferred from a correctness-only GPU run.

## AI usage disclosure

An AI coding assistant was used to inspect the existing serial implementation,
extend independent validation, improve benchmark provenance and plotting checks,
and draft this report section. The user submitted the provided job scripts on
Vanda and downloaded the actual results. The assistant audited those files,
rechecked saved serial solution vectors, calculated summaries and generated the
figures and report. The GPU evidence is a successful Vanda validation log, not
a measured performance-scaling result. The team should review this disclosure
and add any other AI assistance before submission.
