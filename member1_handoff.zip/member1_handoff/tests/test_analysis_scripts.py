"""Integration checks for benchmark provenance and scientific plotting guards.

Run after building: POISSON_SERIAL=build-member1/executables/poisson_serial
python3 -m unittest discover -s tests -p test_analysis_scripts.py -v
Synthetic plotting records exist only in temporary test directories.
"""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AnalysisScripts(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.exe = Path(os.environ.get('POISSON_SERIAL', ROOT / 'build-member1/executables/poisson_serial')).resolve()
        if not self.exe.is_file():
            self.skipTest('Build serial executable first or set POISSON_SERIAL')
        self.csv = self.folder / 'serial.csv'
        self.command = [sys.executable, str(ROOT / 'scripts/benchmark.py'), '--exe', str(self.exe),
                        '--mode', 'serial', '--kind', 'serial', '--sizes', '7', '--iterations', '2',
                        '--repeats', '2', '--output', str(self.csv), '--label', 'test']
        self.run_command(self.command)
        with self.csv.open() as stream:
            self.serial = list(csv.DictReader(stream))[0]

    def run_command(self, command, success=True):
        env = dict(os.environ, MPLCONFIGDIR=str(self.folder / 'mpl'))
        result = subprocess.run(command, capture_output=True, text=True, timeout=60, env=env)
        if success:
            self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0)
        return result

    def plot(self, rows, success=True, serial=False):
        path = self.folder / 'parallel.csv'
        with path.open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
        command = [sys.executable, str(ROOT / 'scripts/plot_scaling.py'), '--input', str(path),
                   '--output-dir', str(self.folder / 'figures')]
        if serial:
            command += ['--serial-reference', str(self.csv)]
        return self.run_command(command, success)

    def records(self):
        return [dict(self.serial, experiment='strong', mode='mpi-cpu', mpi_ranks=str(n),
                     communication='host', solve_seconds=str(t), px=str(p), py=str(p))
                for n, p, t in ((1, 1, 4), (4, 2, 2))]

    def test_provenance_and_no_overwrite(self):
        metadata = json.loads(self.csv.with_suffix('.csv.metadata.json').read_text())
        self.assertEqual(len(metadata['executable_sha256']), 64)
        log = [json.loads(line) for line in self.csv.with_suffix('.csv.runs.jsonl').read_text().splitlines()]
        self.assertEqual([r['event'] for r in log], ['start', 'finish', 'start', 'finish'])
        before = self.csv.read_bytes()
        self.run_command(self.command, success=False)
        self.assertEqual(self.csv.read_bytes(), before)

    def test_reject_equal_size_different_grid(self):
        rows = self.records()
        rows[1].update(nx='49', ny='1')  # Still 49 unknowns, different geometry.
        self.assertIn('grid shape', self.plot(rows, success=False).stderr)

    def test_reject_nonfinite_sample(self):
        rows = self.records()
        rows.append(dict(rows[1], solve_seconds='nan'))
        self.assertIn('finite and positive', self.plot(rows, success=False).stderr)

    def test_speedup_and_serial_reference(self):
        self.plot(self.records(), serial=True)
        with (self.folder / 'figures/summary.csv').open() as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(float(rows[1]['relative_speedup']), 2)
        self.assertEqual(float(rows[1]['efficiency']), .5)
        self.assertAlmostEqual(float(rows[1]['speedup_vs_serial']), float(rows[1]['serial_seconds']) / 2)
        self.assertEqual(len(list((self.folder / 'figures').glob('*.png'))), 4)

    def test_reject_unmatched_serial_reference(self):
        rows = self.records()
        for row in rows:
            row['label'] = 'different-machine'
        self.assertIn('No serial reference matches', self.plot(rows, success=False, serial=True).stderr)


if __name__ == '__main__':
    unittest.main()
