#!/usr/bin/env python3
"""Render the Member 1 Markdown report using ReportLab and Matplotlib equations.

Requires reportlab in this interpreter and matplotlib in --math-python.
The Markdown file remains the editable source of the report.
"""
import argparse
from html import escape
import json
from pathlib import Path
import re
import subprocess
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, KeepTogether, PageBreak
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont


def inline(text):
    text=text.replace('—','-').replace('–','-')
    text=escape(text)
    text=re.sub(r'`([^`]+)`',r'<font name="Courier" size="8.5">\1</font>',text)
    text=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',text)
    return text


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',default='docs/member1_report.md')
    p.add_argument('--output',default='output/pdf/member1_report.pdf')
    p.add_argument('--math-python',default='python3')
    a=p.parse_args();source=Path(a.input);output=Path(a.output)
    output.parent.mkdir(parents=True,exist_ok=True)
    text=source.read_text();temp=Path('tmp/pdfs/member1');temp.mkdir(parents=True,exist_ok=True)
    # Embed available system fonts so PDF viewers do not need substitutions.
    font_dir=Path('/System/Library/Fonts/Supplemental')
    if (font_dir/'Arial.ttf').exists():
        for name,file in [('Helvetica','Arial.ttf'),('Helvetica-Bold','Arial Bold.ttf'),
                          ('Helvetica-Oblique','Arial Italic.ttf'),('Courier','Courier New.ttf')]:
            pdfmetrics.registerFont(TTFont(name,str(font_dir/file)))
    equations=re.findall(r'\\\[(.*?)\\\]',text,re.S)
    math_code='''import json,sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
from matplotlib.mathtext import math_to_image
equations,folder=json.load(sys.stdin)
for i,tex in enumerate(equations):
    math_to_image("$"+" ".join(tex.split())+"$",str(Path(folder)/f"equation{i}.png"),dpi=240,format="png")
'''
    subprocess.run([a.math_python,'-c',math_code],input=json.dumps([equations,str(temp)]),text=True,check=True)
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='ReportBody',fontName='Helvetica',fontSize=10,leading=13.5,spaceAfter=6))
    styles.add(ParagraphStyle(name='EquationLead',parent=styles['ReportBody'],keepWithNext=True))
    styles.add(ParagraphStyle(name='ReportTitle',fontName='Helvetica-Bold',fontSize=19,leading=23,spaceAfter=12))
    styles.add(ParagraphStyle(name='ReportHeading',fontName='Helvetica-Bold',fontSize=12.5,leading=16,
                             spaceBefore=13,spaceAfter=7,keepWithNext=True,textColor=colors.HexColor('#174c6b')))
    styles.add(ParagraphStyle(name='Cell',fontName='Helvetica',fontSize=8,leading=10,alignment=TA_LEFT))
    styles.add(ParagraphStyle(name='Caption',fontName='Helvetica-Oblique',fontSize=8.5,leading=11,spaceAfter=10))
    width=A4[0]-96
    doc=SimpleDocTemplate(str(output),pagesize=A4,rightMargin=48,leftMargin=48,
        topMargin=46,bottomMargin=46,title='Member 1: Serial baseline and validation',author='Project team')
    story=[];lines=text.splitlines();i=0;eq=0
    def picture(path,max_width=width,max_height=235):
        w,h=ImageReader(str(path)).getSize();scale=min(max_width/w,max_height/h)
        return Image(str(path),width=w*scale,height=h*scale,hAlign='CENTER')
    while i<len(lines):
        line=lines[i].strip()
        if not line:
            i+=1;continue
        if line==r'\[':
            while lines[i].strip()!=r'\]':i+=1
            formula=temp/f'equation{eq}.png'
            w,h=ImageReader(str(formula)).getSize();scale=min(86.4/240,(width-15)/w)
            story.extend([Image(str(formula),width=w*scale,height=h*scale,hAlign='CENTER'),Spacer(1,10)])
            eq+=1;i+=1;continue
        if line.startswith('# '):
            story.append(Paragraph(inline(line[2:]),styles['ReportTitle']))
            story.append(Paragraph('DSA5208 Project 3 | Vanda experiments, 10-11 November 2026',styles['Caption']))
            i+=1;continue
        if line.startswith('## '):
            if line[3:] == 'Evidence and remaining group experiments':
                story.append(PageBreak())
            story.append(Paragraph(inline(line[3:]),styles['ReportHeading']));i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[s.strip() for s in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',s) for s in cells):rows.append(cells)
                i+=1
            if len(rows[0])==4:
                weights=[.13,.33,.32,.22]
            elif rows[0][0]=='Problem':
                weights=[.09,.18,.15,.17,.15,.26]
            else:
                weights=[.13,.08,.10,.25,.23,.21]
            table=Table([[Paragraph(inline(s),styles['Cell']) for s in row] for row in rows],
                        colWidths=[width*v for v in weights],repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7eef3')),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),
                ('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),6),
                ('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#8ba6b8')),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f6f8fa')])]))
            story.extend([table,Spacer(1,10)]);continue
        if line.startswith('!['):
            match=re.fullmatch(r'!\[.*\]\((.*)\)',line)
            chart=picture(source.parent/match.group(1));i+=1
            while i<len(lines) and not lines[i].strip():i+=1
            caption=[]
            if i<len(lines) and lines[i].startswith('Figure '):
                while i<len(lines) and lines[i].strip():caption.append(lines[i].strip());i+=1
            story.append(KeepTogether([chart,Spacer(1,5),Paragraph(inline(' '.join(caption)),styles['Caption'])]));continue
        bullet=line.startswith('- ')
        parts=[line[2:] if bullet else line];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![','- ',r'\[')):
            parts.append(lines[i].strip());i+=1
        after=i
        while after<len(lines) and not lines[after].strip():after+=1
        style=styles['EquationLead'] if after<len(lines) and lines[after].strip()==r'\[' else styles['ReportBody']
        paragraph=Paragraph(inline(' '.join(parts)),style,bulletText='-' if bullet else None)
        story.append(paragraph)
    def footer(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#cbd5dc'));canvas.line(48,34,A4[0]-48,34)
        canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#54636d'))
        canvas.drawString(48,22,'DSA5208 | Member 1: serial, validation and benchmarking')
        canvas.drawRightString(A4[0]-48,22,str(doc.page));canvas.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print('Saved',output)


if __name__=='__main__':main()
