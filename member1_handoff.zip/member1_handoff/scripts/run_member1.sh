#!/bin/sh
# Run inside an allocated Vanda compute job, or locally for a smoke check.
# This script has no scheduler directives and does not submit jobs.
set -eu
cd "$(dirname "$0")/.."
build_dir=${1:-build-member1}
output_dir=${2:-results/local-member1}
python_bin=${PYTHON:-python3}
if [ -e "$output_dir" ]; then
    echo "Output directory already exists: $output_dir" >&2
    exit 1
fi
sh scripts/build_serial.sh "$build_dir"
"$python_bin" scripts/validate_serial.py --exe "$build_dir/executables/poisson_serial" \
    --output-dir "$output_dir/validation" --plot
"$python_bin" scripts/benchmark.py --exe "$build_dir/executables/poisson_serial" \
    --mode serial --kind serial --dim 2 --sizes 128 256 512 1024 \
    --iterations 500 --repeats 5 --label "${EXPERIMENT_LABEL:-local-smoke}" \
    --output "$output_dir/serial2d.csv"
"$python_bin" scripts/benchmark.py --exe "$build_dir/executables/poisson_serial" \
    --mode serial --kind serial --dim 3 --sizes 16 32 64 128 \
    --iterations 500 --repeats 5 --label "${EXPERIMENT_LABEL:-local-smoke}" \
    --output "$output_dir/serial3d.csv"
"$python_bin" scripts/plot_scaling.py --input "$output_dir/serial2d.csv" "$output_dir/serial3d.csv" \
    --output-dir "$output_dir/figures"
