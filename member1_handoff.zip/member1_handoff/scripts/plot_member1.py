#!/usr/bin/env python3
"""Render report figures from audited analysis.json; no solver runs."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',default='docs/member1_results/analysis.json')
    a=p.parse_args()
    path=Path(a.input);data=json.loads(path.read_text());out=path.parent
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    colors={2:'#176b98',3:'#c46b23'}
    fig,axes=plt.subplots(1,2,figsize=(10,4.2))
    for dim in (2,3):
        rows=[r for r in data['summary'] if r['dimension']==dim]
        times=[r['median_seconds'] for r in rows]
        errors=[[t-r['min_seconds'] for t,r in zip(times,rows)],
                [r['max_seconds']-t for t,r in zip(times,rows)]]
        for ax,field,label in zip(axes,('unknowns','nonzeros'),('Interior unknowns M','Implicit matrix nonzeros')):
            x=[r[field] for r in rows]
            ax.errorbar(x,times,yerr=errors,marker='o' if dim==2 else 's',capsize=3,color=colors[dim],label=f'{dim}D')
            ax.plot(x,[times[0]*v/x[0] for v in x],':',color=colors[dim],alpha=.7)
            ax.set(xscale='log',yscale='log',xlabel=label,ylabel='Solve time (s)')
            ax.grid(True,which='both',alpha=.18)
    axes[0].legend(title='Median of 5 runs')
    axes[1].text(.04,.94,'Dotted: linear-work reference',transform=axes[1].transAxes,va='top',fontsize=9)
    fig.suptitle('Vanda serial Jacobi: 2,000 iterations on one CPU core',fontsize=12)
    fig.tight_layout()
    fig.savefig(out/'serial_runtime.png',dpi=200);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4))
    for ax,dim in zip(axes,(2,3)):
        rows=[r for r in data['refinement'] if int(r['dimension'])==dim]
        h=[float(r['h']) for r in rows];e=[float(r['error_inf']) for r in rows]
        ax.loglog(h,e,'o-',color=colors[dim],label='Measured maximum error')
        ax.loglog(h,[e[0]*(v/h[0])**2 for v in h],'--',color='#666666',label='Second-order reference')
        ax.set(xlabel='Grid spacing h',ylabel='Maximum solution error',title=f'{dim}D sine problem')
        ax.grid(True,which='both',alpha=.2);ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(out/'refinement.png',dpi=200);plt.close(fig)
    print('Saved serial_runtime.png and refinement.png to',out)


if __name__=='__main__':
    main()
