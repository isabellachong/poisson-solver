#!/usr/bin/env python3
"""Plot benchmark.py CSVs and export median runtime/speedup/efficiency tables.

Requires matplotlib. Non-timing axes use ordinary scale except resource count and
problem size, which use logarithmic scale. GPU sharing never produces a GPU
hardware-efficiency value. GPU strong scaling keeps ranks/GPU or total ranks
constant; GPU weak scaling keeps ranks/GPU constant.
Speedup uses the smallest resource count in each series, identified in the table.
"""
import argparse
from collections import defaultdict
import csv
import math
from pathlib import Path
import re
import statistics


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', nargs='+', required=True)
    p.add_argument('--output-dir', default='results/figures')
    p.add_argument('--serial-reference', nargs='+', help='Optional matched serial benchmark CSVs for serial-to-parallel speedup')
    a = p.parse_args()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    def baseline_key(row):
        return tuple(row[k] for k in ('dimension', 'nx', 'ny', 'nz', 'problem', 'iterations', 'warmup')) + (row.get('label', ''),)
    serial_times = defaultdict(list)
    for filename in a.serial_reference or []:
        with Path(filename).open() as stream:
            for row in csv.DictReader(stream):
                if row['mode'] != 'serial' or int(row['check_every']) != 0:
                    raise ValueError('Serial reference must contain fixed-iteration serial runs')
                seconds = float(row['solve_seconds'])
                if not math.isfinite(seconds) or seconds <= 0:
                    raise ValueError('Serial reference runtime must be finite and positive')
                serial_times[baseline_key(row)].append(seconds)
    series = defaultdict(list)
    for filename in a.input:
        with Path(filename).open() as stream:
            for row in csv.DictReader(stream):
                if int(row['check_every']) != 0:
                    raise ValueError('These plots require matched fixed-iteration measurements')
                key = tuple(row[k] for k in ('experiment', 'mode', 'dimension', 'overlap', 'communication', 'problem', 'iterations'))
                key += (row.get('label', ''), row['warmup'], row['block_size'], row['device_name'])
                series[key].append(row)
    output = Path(a.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    tables = []
    for series_index, (key, rows) in enumerate(series.items()):
        kind, mode, dim, overlap, communication, problem, iterations, label, warmup, block_size, device = key
        if mode == 'mpi-cuda' and any(int(r['gpus_used']) < 1 for r in rows):
            raise ValueError('GPU runs must report at least one GPU')
        if mode == 'mpi-cuda' and kind in ('strong', 'weak'):
            ratios = {int(r['mpi_ranks'])/int(r['gpus_used']) for r in rows}
            fixed_ranks = len({r['mpi_ranks'] for r in rows}) == 1
            if len(ratios) != 1 and (kind == 'weak' or not fixed_ranks):
                raise ValueError('GPU strong scaling must keep ranks/GPU or total MPI ranks constant; weak scaling keeps ranks/GPU constant. A fixed-GPU rank sweep is a sharing study.')
        if kind == 'sharing' and len({r['gpus_used'] for r in rows}) != 1:
            raise ValueError('Sharing input must hold the GPU count fixed')
        resource_key = 'unknowns' if kind == 'serial' else ('gpus_used' if mode == 'mpi-cuda' and kind != 'sharing' else 'mpi_ranks')
        grouped = defaultdict(list)
        for row in rows:
            grouped[int(row[resource_key])].append(row)
        points = sorted(grouped)
        if kind in ('strong', 'sharing') and len({(r['nx'], r['ny'], r['nz']) for r in rows}) != 1:
            raise ValueError('Strong scaling and sharing input must hold the global grid shape fixed')
        if kind == 'weak':
            workloads = {int(r['unknowns'])/int(r[resource_key]) for r in rows}
            if len(workloads) != 1:
                raise ValueError('Weak scaling input must hold unknowns per resource fixed')
        if any(not math.isfinite(float(r['solve_seconds'])) or float(r['solve_seconds']) <= 0 for r in rows):
            raise ValueError('Every runtime must be finite and positive')
        times = [statistics.median(float(r['solve_seconds']) for r in grouped[n]) for n in points]
        low = [min(float(r['solve_seconds']) for r in grouped[n]) for n in points]
        high = [max(float(r['solve_seconds']) for r in grouped[n]) for n in points]
        if min(times) <= 0:
            raise ValueError('Runtime must be positive')
        speedups = [times[0]/t for t in times]
        efficiencies = ([times[0]/t for t in times] if kind == 'weak' else
                        [s/(n/points[0]) for s, n in zip(speedups, points)])
        stem = f'{kind}_{mode}_{dim}d_overlap{overlap}_{communication}_{problem}_k{iterations}'
        stem += f'_series{series_index}' + ('_'+re.sub(r'[^A-Za-z0-9.-]', '_', label) if label else '')
        serial_speedups = []
        for i, n in enumerate(points):
            serial_time = ''
            if a.serial_reference and kind in ('strong', 'sharing'):
                matches = serial_times.get(baseline_key(grouped[n][0]))
                if not matches:
                    raise ValueError('No serial reference matches grid, problem, iterations, warmup and label')
                serial_time = statistics.median(matches)
                serial_speedups.append(serial_time / times[i])
            tables.append(dict(experiment=kind, mode=mode, dimension=dim, overlap=overlap,
                               label=label, problem=problem, iterations=iterations, warmup=warmup,
                               block_size=block_size, device_name=device, samples=len(grouped[n]),
                               communication=communication, resource_axis=resource_key, resources=n,
                               baseline_resources=points[0], median_seconds=times[i], min_seconds=low[i],
                               max_seconds=high[i], relative_speedup='' if kind == 'serial' else speedups[i],
                               serial_seconds=serial_time, speedup_vs_serial=serial_speedups[-1] if serial_time != '' else '',
                               efficiency=efficiencies[i] if kind in ('strong', 'weak') else ''))
        xlabel = {'unknowns': 'Global unknown count', 'mpi_ranks': 'MPI rank count', 'gpus_used': 'GPUs used'}[resource_key]
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.errorbar(points, times, yerr=[[t-l for t, l in zip(times, low)], [h-t for t, h in zip(times, high)]], marker='o', capsize=4)
        title = f'{dim}D {mode}: {kind} runtime\n{problem}, {iterations} iterations'
        if mode != 'serial':
            title += f', overlap={overlap}'
        if label:
            title += '\n' + label
        ax.set(xscale='log', yscale='log', xlabel=xlabel, ylabel='Solve time (s)', title=title)
        ax.grid(True, which='both', alpha=.25)
        fig.tight_layout(); fig.savefig(output/(stem+'_runtime.png'), dpi=180); plt.close(fig)
        if kind in ('strong', 'weak'):
            fig, ax = plt.subplots(figsize=(6, 4))
            ax.plot(points, efficiencies, 'o-')
            ax.set(xscale='log', xlabel=xlabel, ylabel='Parallel efficiency' if kind == 'strong' else 'Weak-scaling efficiency',
                   title=f'Baseline: {points[0]} {xlabel.lower()}')
            ax.grid(True, which='both', alpha=.25)
            fig.tight_layout(); fig.savefig(output/(stem+'_efficiency.png'), dpi=180); plt.close(fig)
        if kind in ('strong', 'sharing'):
            fig, ax = plt.subplots(figsize=(6, 4))
            ax.plot(points, speedups, 'o-')
            ax.set(xscale='log', xlabel=xlabel, ylabel='Relative speedup', title=f'Baseline: {points[0]} {xlabel.lower()}')
            ax.grid(True, which='both', alpha=.25)
            fig.tight_layout(); fig.savefig(output/(stem+'_speedup.png'), dpi=180); plt.close(fig)
        if serial_speedups:
            fig, ax = plt.subplots(figsize=(6, 4))
            ax.plot(points, serial_speedups, 'o-')
            ax.set(xscale='log', xlabel=xlabel, ylabel='Serial CPU time / parallel time', title='Matched serial baseline')
            ax.grid(True, which='both', alpha=.25)
            fig.tight_layout(); fig.savefig(output/(stem+'_serial_speedup.png'), dpi=180); plt.close(fig)
    if tables:
        with (output/'summary.csv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(tables[0]))
            writer.writeheader(); writer.writerows(tables)
    print(f'Saved figures and median summary to {output}')


if __name__ == '__main__':
    main()
