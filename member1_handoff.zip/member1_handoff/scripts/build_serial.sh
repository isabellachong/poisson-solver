#!/bin/sh
# Portable fallback for machines with a C++17 compiler but no CMake/MPI/CUDA.
set -eu
cd "$(dirname "$0")/.."
build_dir=${1:-build-member1}
mkdir -p "$build_dir/executables" "$build_dir/tests"
for target in poisson_serial poisson_tests; do
    case "$target" in
        poisson_serial) main=executables/poisson_serial.cpp; destination=executables ;;
        poisson_tests) main=tests/test_numerics.cpp; destination=tests ;;
    esac
    "${CXX:-c++}" -std=c++17 -O3 -DNDEBUG -Wall -Wextra -Wpedantic -Isrc \
        src/config.cpp src/problem.cpp src/decomposition.cpp src/cpu_backend.cpp \
        src/solver.cpp src/io_utils.cpp "$main" -o "$build_dir/$destination/$target"
done
for check in decomposition stencil regions exchange2d exchange3d convergence configuration; do
    "$build_dir/tests/poisson_tests" "$check"
done
