#!/usr/bin/env python3
"""Audit downloaded Vanda measurements and export report data (standard library)."""
import argparse
from collections import defaultdict
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
sys.path.insert(0, str(ROOT / 'scripts'))
from validate_mpi import check_solution, reference
from validate_serial import modal_reference


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', default='results/vanda-member1-serial-1542371.stdct-mgmt-02')
    p.add_argument('--gpu-log', default='results/vanda-gpu-validate-1537115.stdct-mgmt-02/job.log')
    p.add_argument('--output', default='docs/member1_results')
    a = p.parse_args()
    source, output = Path(a.input), Path(a.output)
    output.mkdir(parents=True, exist_ok=True)
    summary, hashes, slopes = [], {}, {}
    for dim in (2, 3):
        path = source / f'serial{dim}d.csv'
        rows = read_csv(path)
        meta = json.loads(path.with_suffix('.csv.metadata.json').read_text())
        trace = [json.loads(line) for line in path.with_suffix('.csv.runs.jsonl').read_text().splitlines()]
        require(len(rows) == 20 and len(trace) == 40, 'Missing benchmark records')
        groups = defaultdict(list)
        for i, row in enumerate(rows):
            require(trace[2*i]['event'] == 'start' and trace[2*i+1]['event'] == 'finish', 'Incomplete run trace')
            require(trace[2*i+1]['returncode'] == 0, 'A solver invocation failed')
            raw = list(csv.DictReader(io.StringIO(trace[2*i+1]['stdout'])))[0]
            require(all(row[k] == v for k, v in raw.items()), 'CSV differs from captured solver output')
            require(row['mode'] == 'serial' and int(row['dimension']) == dim, 'Incorrect solver mode')
            require(int(row['iterations']) == 2000 and int(row['check_every']) == 0 and int(row['warmup']) == 3,
                    'Mismatched benchmark settings')
            require(row['problem'] == 'mixed' and int(row['mpi_ranks']) == 1 and int(row['gpus_used']) == 0,
                    'Unexpected resources or problem')
            nx, ny, nz = (int(row['n'+axis]) for axis in 'xyz')
            require(nx == ny and (nz == nx if dim == 3 else nz == 1), 'Unexpected grid shape')
            m = nx*ny*nz
            nnz = 5*m-2*(nx+ny) if dim == 2 else 7*m-2*(nx*ny+nx*nz+ny*nz)
            require(int(row['unknowns']) == m and int(row['nonzeros']) == nnz, 'Incorrect matrix counts')
            for field in ('solve_seconds', 'residual_inf', 'error_inf'):
                require(math.isfinite(float(row[field])) and float(row[field]) >= 0, 'Nonfinite result')
            require(float(row['solve_seconds']) > 0, 'Nonpositive runtime')
            groups[nx].append(row)
        expected = [128, 256, 512, 1024] if dim == 2 else [16, 32, 64, 128]
        require(sorted(groups) == expected, 'Unexpected benchmark sizes')
        for n, group in sorted(groups.items()):
            require(sorted(int(r['repeat']) for r in group) == list(range(5)), 'Missing or duplicate repeats')
            times = [float(r['solve_seconds']) for r in group]
            row = group[0]
            summary.append(dict(dimension=dim, n=n, unknowns=int(row['unknowns']), nonzeros=int(row['nonzeros']),
                repeats=5, iterations=2000, median_seconds=statistics.median(times), min_seconds=min(times),
                max_seconds=max(times), million_updates_per_second=int(row['unknowns'])*2000/statistics.median(times)/1e6,
                converged_runs=sum(int(r['converged']) for r in group)))
        entries = [r for r in summary if r['dimension'] == dim]
        x = [math.log(r['unknowns']) for r in entries]
        y = [math.log(r['median_seconds']) for r in entries]
        mx, my = statistics.mean(x), statistics.mean(y)
        slopes[str(dim)] = sum((u-mx)*(v-my) for u,v in zip(x,y))/sum((u-mx)**2 for u in x)
        hashes[str(dim)] = meta['executable_sha256']
    require(len(set(hashes.values())) == 1, 'Dimensions used different executables')
    checks = read_csv(source / 'validation/checks.csv')
    require(len(checks) == 64, 'Incomplete fixed-step validation table')
    for row in checks:
        dim, steps = int(row['dimension']), int(row['iterations'])
        sizes = tuple(int(row['n'+axis]) for axis in 'xyz')
        problem = row['problem']
        require(row['status'] == 'passed', 'Failed validation record')
        if problem == 'polynomial':
            expected, residual = reference(dim, sizes, steps)
        else:
            expected, residual = modal_reference(dim, sizes, steps, problem)
            if problem == 'zero':
                expected, residual = dict.fromkeys(expected, 0.0), 0.0
        check_solution(source / 'validation' / f'{dim}d_{sizes[0]}_{problem}_{steps}', expected)
        require(math.isclose(float(row['residual_inf']), residual, rel_tol=1e-10, abs_tol=1e-9),
                'Independent residual check failed')
    refinement = read_csv(source / 'validation/refinement.csv')
    require(len(refinement) == 6, 'Incomplete refinement table')
    for dim in (2, 3):
        group = sorted((r for r in refinement if int(r['dimension']) == dim), key=lambda r:int(r['n']))
        require([int(r['n']) for r in group] == [7,15,31], 'Unexpected refinement grids')
        for i,r in enumerate(group):
            require(float(r['residual_inf']) <= float(r['threshold']), 'Refinement did not converge')
            if i:
                order = math.log2(float(group[i-1]['error_inf'])/float(r['error_inf']))
                require(1.9 < order < 2.1 and math.isclose(order,float(r['observed_order'])), 'Incorrect refinement order')
    require('MEMBER1_SERIAL_OK' in (source / 'job.log').read_text(), 'Missing serial completion marker')
    gpu_log = Path(a.gpu_log).read_text()
    require('GPU_VALIDATION_OK' in gpu_log and 'Passed 8 executable checks' in gpu_log,
            'Missing GPU validation completion')
    sources = [*source.glob('serial*d.csv*'), source/'job.log', source/'validation/checks.csv',
               source/'validation/refinement.csv', Path(a.gpu_log), Path('jobs/vanda_member1_serial.pbs'),
               Path('jobs/vanda_gpu_validate.pbs')]
    manifest = {str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in sources}
    result = dict(summary=summary, refinement=refinement, loglog_slopes=slopes,
                  serial_executable_sha256=hashes['2'], source_sha256=manifest,
                  audit='40 timings match captured solver output; 64 downloaded solution vectors independently rechecked; six refinement solves verified.',
                  gpu_evidence='Imported successful eight-check validator log; GPU owned-value files were temporary and are not in the archive.')
    (output/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    with (output/'serial_summary.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
    print(result['audit'])
    print('Log-log slopes T versus M:', slopes)
    for row in summary:
        print(row)


if __name__ == '__main__':
    main()
