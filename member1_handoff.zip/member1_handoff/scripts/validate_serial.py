#!/usr/bin/env python3
"""Member 1: independent executable checks and measured grid-refinement tables.

Uses only the standard library unless --plot is requested. Outputs actual solver
measurements, never fabricated cluster results. Existing output directories fail.
"""
import argparse
import csv
import json
import math
from pathlib import Path
import platform
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
from validate_mpi import check_solution, execute, reference


def modal_reference(dim, sizes, steps, problem):
    """Exact finite-step Jacobi result from discrete sine eigenvalues.

    This does not reproduce the stencil loop and catches shared stencil bugs.
    For one sine mode: amplitude = lambda_cont/lambda_disc * (1-rho**steps).
    """
    modes = [(1.0, (1,) * dim)]
    if problem == 'mixed':
        modes.append((0.25, (2, 3) + ((1,) if dim == 3 else ())))
    diagonal = 2 * sum((n + 1)**2 for n in sizes[:dim])
    expected, residual = {}, 0.0
    for k in (range(1, sizes[2]+1) if dim == 3 else [0]):
        for j in range(1, sizes[1]+1):
            for i in range(1, sizes[0]+1):
                xyz = (i, j, k)
                value, r = 0.0, 0.0
                for amplitude, frequencies in modes:
                    continuous = math.pi**2 * sum(m*m for m in frequencies)
                    discrete = 4 * sum((sizes[a]+1)**2 * math.sin(m*math.pi/(2*(sizes[a]+1)))**2
                                       for a, m in enumerate(frequencies))
                    rho = 1 - discrete / diagonal
                    basis = math.prod(math.sin(m*math.pi*xyz[a]/(sizes[a]+1))
                                      for a, m in enumerate(frequencies))
                    value += amplitude * continuous/discrete * (1-rho**steps) * basis
                    r += amplitude * continuous * rho**steps * basis
                expected[(i, j, k)] = value
                residual = max(residual, abs(r))
    return expected, residual


def write_csv(path, rows):
    with path.open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--exe', default='build-member1/executables/poisson_serial')
    p.add_argument('--output-dir', default='results/local-validation')
    p.add_argument('--plot', action='store_true')
    args = p.parse_args()
    exe = str(Path(args.exe).resolve())
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    commands, checks, refinement = [], [], []

    def run(arguments):
        command = [exe, *map(str, arguments)]
        commands.append(command)
        return execute(command)

    for dim in (2, 3):
        # Unequal spacings, degenerate/thin domains, zero/even/odd swap counts,
        # all shared manufactured problems, and warm-up followed by reset.
        for sizes in ((9, 7, 5), (1, 2, 3)):
            for problem in ('polynomial', 'sine', 'mixed', 'zero'):
                for steps in (0, 1, 2, 9):
                    prefix = output / f'{dim}d_{sizes[0]}_{problem}_{steps}'
                    row = run(['--dim', dim, '--nx', sizes[0], '--ny', sizes[1], '--nz', sizes[2],
                               '--problem', problem, '--iterations', steps, '--warmup', 2,
                               '--check-every', 0, '--solution-prefix', prefix])
                    if problem == 'polynomial':
                        expected, residual = reference(dim, sizes, steps)
                    else:
                        expected, residual = modal_reference(dim, sizes, steps, problem)
                        if problem == 'zero':
                            expected = dict.fromkeys(expected, 0.0)
                            residual = 0.0
                    check_solution(prefix, expected)
                    if int(row['iterations']) != steps or row['mode'] != 'serial':
                        raise AssertionError('Incorrect execution mode or iteration count')
                    if not math.isclose(float(row['residual_inf']), residual, rel_tol=1e-10, abs_tol=1e-9):
                        raise AssertionError(f'Independent residual mismatch: {prefix}')
                    checks.append(dict(dimension=dim, nx=sizes[0], ny=sizes[1], nz=sizes[2] if dim == 3 else 1,
                                       problem=problem, iterations=steps, status='passed',
                                       residual_inf=row['residual_inf']))
        previous = None
        for n in (7, 15, 31):
            row = run(['--dim', dim, '--nx', n, '--ny', n, '--nz', n, '--problem', 'sine',
                       '--iterations', 50000, '--check-every', 10, '--warmup', 2,
                       '--rtol', '1e-11', '--atol', '1e-12'])
            error = float(row['error_inf'])
            if row['converged'] != '1' or float(row['residual_inf']) > float(row['threshold']):
                raise AssertionError('Refinement solve did not converge')
            order = math.log2(previous / error) if previous is not None else ''
            if order != '' and not 1.9 < order < 2.1:
                raise AssertionError(f'Expected second-order accuracy, got {order}')
            refinement.append(dict(dimension=dim, n=n, h=1/(n+1), error_inf=error,
                                   error_rms=row['error_rms'], observed_order=order,
                                   iterations=row['iterations'], residual_inf=row['residual_inf'],
                                   threshold=row['threshold'], solve_seconds=row['solve_seconds']))
            previous = error
    # Existing suite also verifies initial convergence and failure exit status.
    subprocess.run([sys.executable, str(Path(__file__).resolve().parents[1] / 'tests/validate_mpi.py'),
                    '--serial-only', '--serial', exe], check=True)
    write_csv(output / 'checks.csv', checks)
    write_csv(output / 'refinement.csv', refinement)
    (output / 'run.json').write_text(json.dumps(dict(platform=platform.platform(),
        python=sys.version, executable=exe, commands=commands,
        note='Local numerical validation; not Atlas/Vanda performance data.'), indent=2)+'\n')
    if args.plot:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6, 4))
        for dim in (2, 3):
            rows = [r for r in refinement if r['dimension'] == dim]
            h = [r['h'] for r in rows]
            error = [r['error_inf'] for r in rows]
            ax.loglog(h, error, 'o-', label=f'{dim}D measured')
        ax.loglog(h, [error[0]*(x/h[0])**2 for x in h], '--', color='gray', label='Second-order reference')
        ax.set(xlabel='Grid spacing h', ylabel='Maximum solution error', title='Serial Jacobi grid refinement')
        ax.legend(); ax.grid(True, which='both', alpha=.25)
        fig.tight_layout(); fig.savefig(output / 'refinement.png', dpi=180); plt.close(fig)
    print(f'Passed {len(checks)} fixed-step cases and {len(refinement)} refinement solves; saved {output}')


if __name__ == '__main__':
    main()
